<?php
// session.php — Shared Session & Cookie Handler
// Include this at the TOP of every PHP page with:
//   require_once 'session.php';

session_start();

// ── COOKIE: Theme Preference ──────────────────────────────────
// Read theme from cookie, default to 'classic'
$allowed_themes = ['classic', 'midnight', 'sepia', 'frost'];
$current_theme  = 'classic';

if (isset($_COOKIE['luminary_theme']) && in_array($_COOKIE['luminary_theme'], $allowed_themes)) {
    $current_theme = $_COOKIE['luminary_theme'];
}

// If theme was just changed via GET param, update cookie
if (isset($_GET['theme']) && in_array($_GET['theme'], $allowed_themes)) {
    $current_theme = $_GET['theme'];
    // Cookie expires in 30 days
    setcookie('luminary_theme', $current_theme, time() + (30 * 24 * 60 * 60), '/');
}

// ── SESSION: Login check helper ───────────────────────────────
function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// ── SESSION: Get logged-in user's name ────────────────────────
function get_user_name() {
    return isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'Guest';
}

function get_user_email() {
    return isset($_SESSION['user_email']) ? htmlspecialchars($_SESSION['user_email']) : '';
}

// ── THEME CSS VARIABLES ───────────────────────────────────────
// Returns inline CSS for the chosen theme
function get_theme_css($theme) {
    $themes = [
        'classic'  => ['--ink:#0d0d0d', '--paper:#f5f0e8', '--cream:#faf7f2', '--gold:#c8922a', '--gold-light:#e8b84b', '--muted:#8a8278', '--border:#d8cfc0'],
        'midnight' => ['--ink:#e8e4dc', '--paper:#1a1a1a', '--cream:#141414', '--gold:#e8b84b', '--gold-light:#f5d07a', '--muted:#6a6460', '--border:#2a2a2a'],
        'sepia'    => ['--ink:#2c1a0e', '--paper:#f2e8d5', '--cream:#faf4e8', '--gold:#a0621a', '--gold-light:#c8922a', '--muted:#7a6a58', '--border:#c8b898'],
        'frost'    => ['--ink:#1a2a3a', '--paper:#eef4fb', '--cream:#f5f9ff', '--gold:#2a7ab8', '--gold-light:#4a9ad8', '--muted:#6a8298', '--border:#c8d8e8'],
    ];
    $vars = isset($themes[$theme]) ? $themes[$theme] : $themes['classic'];
    return ':root { ' . implode('; ', $vars) . '; }';
}
?>
