<?php
// logout.php — Destroys session and redirects to login page
require_once 'session.php';

// Destroy all session data
$_SESSION = [];
session_destroy();

// NOTE: We do NOT delete the theme cookie on logout.
// The theme preference is a UI preference, not auth data.
// It persists across sessions intentionally.

// Redirect to login page
header('Location: login.php');
exit;
?>
